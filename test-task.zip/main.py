import requests
from bs4 import BeautifulSoup
from collections import Counter

url = 'https://uk.wikipedia.org/wiki/%D0%A1%D0%BF%D0%B8%D1%81%D0%BE%D0%BA_%D0%BA%D1%80%D0%B0%D1%97%D0%BD_%D0%84%D0%B2%D1%80%D0%BE%D0%BF%D0%B8_%D0%B7%D0%B0_%D0%BF%D0%BB%D0%BE%D1%89%D0%B5%D1%8E'
get_page = requests.get(url).text
soup = BeautifulSoup(get_page, 'lxml')
countries_table = soup.find('table', {'class': 'wikitable sortable'}).findAll('a')
#Задано url та команду знайти таблицю з країнами, в якій необхідно знайти всі теги <а, в яких зберігаються title з назвами країн

countries = []
for i in countries_table:
    countries.append(i.get('title'))
countries_set = set(countries)
countries_lst = list(countries_set)
countries_lst.remove('Росія')
#Створено пустий список, в який додано всі назви країн, які зберігаються у title.
#Оскільки під title дублювались назви, використано set, щоб збереги унікальні значення і перетворено послідовність назад у список.
# remove використано, щоб викинути росію

countries_flag = soup.find('table', {'class': 'wikitable sortable'}).findAll('img', {'class':'thumbborder'})
flag_url = {}
for image in countries_flag:
    flag_url[image.get('alt')]= image.get('src')
flag_url.pop('Росія')
#Використано словник, ключем якого є назва країни, а значенням посилання на прапор. Аналогічно видалено росію

quantity_letters = Counter(i[0] for i in countries_lst)
#Використано Counter для підрахунку кількості однакових перших літер




class Countries:
    def __init__(self, name):
        self.name = name


    def func_cap(self):
        if self.name in countries_lst:
            return quantity_letters.get(self.name[0])
            #Даний метод перевіряє назву країни на наявність у списку та повертає кількість однакових перших літер з назв країн у списку

    def func_for_flag(self):
         if self.name in flag_url:
             return flag_url.get(self.name)
            #Даний метод перевіряє назву країни на навність у словнику та повертає значення url прапора за ключем, тобто за назвою

    def func_for_dct(self):
        dct_countries = {'country':self.name,
                         'same_letter_count':self.func_cap(),
                         'flag_url':self.func_for_flag()}


        lst_dct = []
        if self.name in countries_lst:
            lst_dct.append(dct_countries)
        return lst_dct
        #Даний метод ствоює словник та повертає список словника





obj = Countries('Австрія')
obj_2 = Countries('Швеція')
obj_3 = Countries('Австралія')
obj_4 = Countries('Бразилія')#В списку лише країни Європи, тому Австралія та Бразилія не проходять

print(obj.func_for_dct())
print(obj_2.func_for_dct())
print(obj_3.func_for_dct())
print(obj_4.func_for_dct())

